package com.friendchat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
	public String url = "ws://localhost:8080";
	public String username = "";
	public String password = "";

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	public static Config INSTANCE = new Config();

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("friendchat.json");
	}

	public static void load() {
		try {
			Path p = path();
			if (Files.exists(p)) {
				Config c = GSON.fromJson(Files.readString(p), Config.class);
				if (c != null) INSTANCE = c;
			}
		} catch (Exception e) {
			FriendChatClient.LOGGER.warn("Could not load config", e);
		}
	}

	public static void save() {
		try {
			Files.writeString(path(), GSON.toJson(INSTANCE));
		} catch (Exception e) {
			FriendChatClient.LOGGER.warn("Could not save config", e);
		}
	}
}
