package com.friendchat;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FriendChatClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("friendchat");

	@Override
	public void onInitializeClient() {
		Config.load();

		// Adds a "Friends" button to the main menu and to the pause menu (works in singleplayer too).
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			if (screen instanceof TitleScreen || screen instanceof GameMenuScreen) {
				int unread = ChatClient.INSTANCE.unread.values().stream().mapToInt(Integer::intValue).sum();
				Text label = Text.literal(unread > 0 ? "Friends (" + unread + ")" : "Friends");
				Screens.getButtons(screen).add(
					ButtonWidget.builder(label, b -> open(client, screen)).dimensions(6, 6, 80, 20).build());
			}
		});

		if (!Config.INSTANCE.username.isEmpty() && !Config.INSTANCE.password.isEmpty()) {
			ChatClient.INSTANCE.connect();
		}
	}

	static void open(MinecraftClient client, Screen from) {
		if (ChatClient.INSTANCE.status == ChatClient.Status.ONLINE) {
			client.setScreen(new ChatScreen(from));
		} else {
			client.setScreen(new LoginScreen(from));
		}
	}
}
