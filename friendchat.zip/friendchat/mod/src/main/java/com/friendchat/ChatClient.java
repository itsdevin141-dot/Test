package com.friendchat;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.toast.SystemToast;
import net.minecraft.text.Text;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Networking + state. All state is only touched on the Minecraft main thread. */
public final class ChatClient {
	public static final ChatClient INSTANCE = new ChatClient();
	private static final Gson GSON = new Gson();

	public enum Status { OFFLINE, CONNECTING, ONLINE, AUTH_FAILED }

	public record Msg(String from, String text, long ts) {}

	public static final class Group {
		public String id;
		public String name;
		public List<String> members = new ArrayList<>();
	}

	public Status status = Status.OFFLINE;
	public String statusText = "";
	public String self = "";
	public final Map<String, Boolean> friends = new LinkedHashMap<>();
	public final List<String> requests = new ArrayList<>();
	public final Map<String, Group> groups = new LinkedHashMap<>();
	public final Map<String, List<Msg>> history = new HashMap<>();
	public final Map<String, Integer> unread = new HashMap<>();
	public final List<String> notices = new ArrayList<>();
	/** "home", "dm:Name", "grp:id", or null when the chat screen is closed. */
	public String openConvo = null;

	private final Set<Runnable> listeners = new LinkedHashSet<>();
	private final HttpClient http = HttpClient.newHttpClient();
	private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
		Thread t = new Thread(r, "friendchat-reconnect");
		t.setDaemon(true);
		return t;
	});

	private volatile int generation = 0;
	private WebSocket ws;
	private boolean wantConnected = false;
	private CompletableFuture<?> chain = CompletableFuture.completedFuture(null);

	private ChatClient() {}

	// ---------- listeners ----------
	public void addListener(Runnable r) { listeners.add(r); }
	public void removeListener(Runnable r) { listeners.remove(r); }
	private void changed() { for (Runnable r : new ArrayList<>(listeners)) r.run(); }

	// ---------- connection ----------
	public synchronized void connect() {
		final int gen = ++generation;
		closeSocket();
		wantConnected = true;
		setStatus(Status.CONNECTING, "Connecting...");
		try {
			http.newWebSocketBuilder()
				.connectTimeout(Duration.ofSeconds(10))
				.buildAsync(URI.create(Config.INSTANCE.url), new Listener(gen))
				.whenComplete((w, e) -> {
					if (e != null) onDown(gen, "Cannot connect to server");
				});
		} catch (Exception e) {
			onDown(gen, "Invalid server URL");
		}
	}

	public synchronized void disconnect() {
		wantConnected = false;
		generation++;
		closeSocket();
		friends.clear();
		requests.clear();
		groups.clear();
		history.clear();
		unread.clear();
		self = "";
		setStatus(Status.OFFLINE, "Logged out");
	}

	private void closeSocket() {
		if (ws != null) {
			try { ws.sendClose(WebSocket.NORMAL_CLOSURE, "bye"); } catch (Exception ignored) {}
			ws = null;
		}
	}

	private void onDown(int gen, String message) {
		post(gen, () -> {
			synchronized (this) { ws = null; }
			if (status == Status.AUTH_FAILED) return;
			for (String f : friends.keySet()) friends.put(f, false);
			setStatus(Status.OFFLINE, message + " - retrying...");
			if (wantConnected) {
				scheduler.schedule(() -> MinecraftClient.getInstance().execute(() -> {
					if (gen == generation && wantConnected) connect();
				}), 5, TimeUnit.SECONDS);
			}
		});
	}

	private void post(int gen, Runnable r) {
		MinecraftClient.getInstance().execute(() -> {
			if (gen == generation) r.run();
		});
	}

	private void setStatus(Status s, String text) {
		status = s;
		statusText = text;
		changed();
	}

	private final class Listener implements WebSocket.Listener {
		private final int gen;
		private final StringBuilder buf = new StringBuilder();

		Listener(int gen) { this.gen = gen; }

		@Override
		public void onOpen(WebSocket w) {
			synchronized (ChatClient.this) {
				if (gen != generation) { w.abort(); return; }
				ws = w;
			}
			JsonObject o = new JsonObject();
			o.addProperty("t", "login");
			o.addProperty("name", Config.INSTANCE.username);
			o.addProperty("pass", Config.INSTANCE.password);
			send(o);
			w.request(1);
		}

		@Override
		public CompletionStage<?> onText(WebSocket w, CharSequence data, boolean last) {
			buf.append(data);
			if (last) {
				String s = buf.toString();
				buf.setLength(0);
				post(gen, () -> handle(s));
			}
			w.request(1);
			return null;
		}

		@Override
		public CompletionStage<?> onClose(WebSocket w, int code, String reason) {
			onDown(gen, "Disconnected");
			return null;
		}

		@Override
		public void onError(WebSocket w, Throwable error) {
			onDown(gen, "Connection error");
		}
	}

	private synchronized void send(JsonObject o) {
		final WebSocket w = ws;
		if (w == null) return;
		final String s = GSON.toJson(o);
		chain = chain.handle((r, e) -> null).thenCompose(v -> w.sendText(s, true));
	}

	// ---------- incoming ----------
	private static String str(JsonObject o, String k) {
		JsonElement e = o.get(k);
		return e == null || e.isJsonNull() ? "" : e.getAsString();
	}

	private void handle(String raw) {
		JsonObject o;
		try { o = JsonParser.parseString(raw).getAsJsonObject(); } catch (Exception e) { return; }
		switch (str(o, "t")) {
			case "auth_ok" -> { self = str(o, "name"); setStatus(Status.ONLINE, "Connected as " + self); }
			case "auth_fail" -> { wantConnected = false; setStatus(Status.AUTH_FAILED, str(o, "reason")); }
			case "state" -> applyState(o);
			case "presence" -> { friends.put(str(o, "name"), o.get("online").getAsBoolean()); changed(); }
			case "msg" -> onMsg(o);
			case "info" -> notice(str(o, "text"));
			default -> { }
		}
	}

	private void applyState(JsonObject o) {
		friends.clear();
		for (JsonElement e : o.getAsJsonArray("friends")) {
			JsonObject f = e.getAsJsonObject();
			friends.put(str(f, "name"), f.get("online").getAsBoolean());
		}
		requests.clear();
		for (JsonElement e : o.getAsJsonArray("requests")) requests.add(e.getAsString());
		groups.clear();
		for (JsonElement e : o.getAsJsonArray("groups")) {
			JsonObject g = e.getAsJsonObject();
			Group grp = new Group();
			grp.id = str(g, "id");
			grp.name = str(g, "name");
			for (JsonElement m : g.getAsJsonArray("members")) grp.members.add(m.getAsString());
			groups.put(grp.id, grp);
		}
		if (o.has("history")) {
			history.clear();
			for (Map.Entry<String, JsonElement> en : o.getAsJsonObject("history").entrySet()) {
				List<Msg> list = new ArrayList<>();
				for (JsonElement me : en.getValue().getAsJsonArray()) {
					JsonObject m = me.getAsJsonObject();
					list.add(new Msg(str(m, "from"), str(m, "text"), m.get("ts").getAsLong()));
				}
				history.put(en.getKey(), list);
			}
		}
		if (openConvo != null && !openConvo.equals("home") && !hasConvo(openConvo)) openConvo = "home";
		changed();
	}

	private boolean hasConvo(String key) {
		if (key.startsWith("dm:")) return friends.containsKey(key.substring(3));
		if (key.startsWith("grp:")) return groups.containsKey(key.substring(4));
		return true;
	}

	private void onMsg(JsonObject o) {
		String convo = str(o, "convo");
		Msg m = new Msg(str(o, "from"), str(o, "text"), o.get("ts").getAsLong());
		List<Msg> list = history.computeIfAbsent(convo, k -> new ArrayList<>());
		list.add(m);
		while (list.size() > 200) list.remove(0);
		if (!convo.equals(openConvo) && !m.from().equals(self)) {
			unread.merge(convo, 1, Integer::sum);
			String title = m.from();
			if (convo.startsWith("grp:")) {
				Group g = groups.get(convo.substring(4));
				if (g != null) title = g.name + " - " + m.from();
			}
			toast(title, m.text());
		}
		changed();
	}

	public void notice(String text) {
		notices.add(text);
		while (notices.size() > 30) notices.remove(0);
		toast("Friend Chat", text);
		changed();
	}

	private void toast(String title, String body) {
		String b = body.length() > 60 ? body.substring(0, 60) + "..." : body;
		MinecraftClient mc = MinecraftClient.getInstance();
		SystemToast.add(mc.getToastManager(), SystemToast.Type.PERIODIC_NOTIFICATION, Text.literal(title), Text.literal(b));
	}

	// ---------- outgoing ----------
	private static JsonObject obj(String... kv) {
		JsonObject o = new JsonObject();
		for (int i = 0; i + 1 < kv.length; i += 2) o.addProperty(kv[i], kv[i + 1]);
		return o;
	}

	public void sendDm(String to, String text) { send(obj("t", "dm", "to", to, "text", text)); }
	public void sendGroupMsg(String groupId, String text) { send(obj("t", "group_msg", "group", groupId, "text", text)); }
	public void friendAdd(String name) { send(obj("t", "friend_add", "name", name)); }
	public void friendAccept(String name) { send(obj("t", "friend_accept", "name", name)); }
	public void friendRemove(String name) { send(obj("t", "friend_remove", "name", name)); }
	public void groupCreate(String name) { send(obj("t", "group_create", "name", name)); }
	public void groupAdd(String groupId, String name) { send(obj("t", "group_add", "group", groupId, "name", name)); }
	public void groupLeave(String groupId) { send(obj("t", "group_leave", "group", groupId)); }

	public Group findGroup(String name) {
		for (Group g : groups.values()) if (g.name.equalsIgnoreCase(name)) return g;
		return null;
	}
}
