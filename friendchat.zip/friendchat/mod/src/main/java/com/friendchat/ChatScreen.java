package com.friendchat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.time.Instant;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ChatScreen extends Screen {
	private static final int LIST_W = 130;
	private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

	private final Screen parent;
	private TextFieldWidget input;
	private String draft = "";
	private int listOffset = 0;
	private final Runnable listener = this::refresh;

	private record Entry(String key, Text label) {}

	public ChatScreen(Screen parent) {
		super(Text.literal("Friend Chat"));
		this.parent = parent;
		if (ChatClient.INSTANCE.openConvo == null) ChatClient.INSTANCE.openConvo = "home";
	}

	private List<Entry> entries() {
		ChatClient c = ChatClient.INSTANCE;
		List<Entry> list = new ArrayList<>();
		List<Map.Entry<String, Boolean>> fl = new ArrayList<>(c.friends.entrySet());
		fl.sort((a, b) -> {
			if (a.getValue() != b.getValue()) return a.getValue() ? -1 : 1;
			return a.getKey().compareToIgnoreCase(b.getKey());
		});
		for (Map.Entry<String, Boolean> f : fl) {
			String key = "dm:" + f.getKey();
			MutableText t = Text.literal(f.getValue() ? "\u25CF " : "\u25CB ")
				.formatted(f.getValue() ? Formatting.GREEN : Formatting.GRAY);
			t.append(Text.literal(f.getKey()).formatted(key.equals(c.openConvo) ? Formatting.YELLOW : Formatting.WHITE));
			int u = c.unread.getOrDefault(key, 0);
			if (u > 0) t.append(Text.literal(" (" + u + ")").formatted(Formatting.GOLD));
			list.add(new Entry(key, t));
		}
		for (ChatClient.Group g : c.groups.values()) {
			String key = "grp:" + g.id;
			MutableText t = Text.literal("# ").formatted(Formatting.AQUA);
			t.append(Text.literal(g.name).formatted(key.equals(c.openConvo) ? Formatting.YELLOW : Formatting.WHITE));
			int u = c.unread.getOrDefault(key, 0);
			if (u > 0) t.append(Text.literal(" (" + u + ")").formatted(Formatting.GOLD));
			list.add(new Entry(key, t));
		}
		return list;
	}

	@Override
	protected void init() {
		ChatClient c = ChatClient.INSTANCE;
		List<Entry> entries = entries();
		int visible = Math.max(1, (height - 60 - 30) / 22);
		listOffset = Math.max(0, Math.min(listOffset, Math.max(0, entries.size() - visible)));

		addDrawableChild(ButtonWidget.builder(Text.literal("Home / Help"), b -> select("home"))
			.dimensions(6, 6, LIST_W, 20).build());
		for (int i = 0; i < visible && i + listOffset < entries.size(); i++) {
			Entry e = entries.get(i + listOffset);
			addDrawableChild(ButtonWidget.builder(e.label(), b -> select(e.key()))
				.dimensions(6, 30 + 22 * i, LIST_W, 20).build());
		}
		addDrawableChild(ButtonWidget.builder(Text.literal("^"), b -> { listOffset = Math.max(0, listOffset - 1); refresh(); })
			.dimensions(6, height - 54, 30, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("v"), b -> { listOffset++; refresh(); })
			.dimensions(40, height - 54, 30, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Logout"), b -> logout())
			.dimensions(74, height - 54, LIST_W - 68, 20).build());

		int x0 = LIST_W + 12;
		int x1 = width - 6;
		input = new TextFieldWidget(textRenderer, x0, height - 26, x1 - x0 - 60, 20, Text.literal("Message"));
		input.setMaxLength(500);
		input.setPlaceholder(Text.literal("Message or /command..."));
		input.setText(draft);
		input.setChangedListener(s -> draft = s);
		addDrawableChild(input);
		addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> submit())
			.dimensions(x1 - 56, height - 26, 56, 20).build());
		setInitialFocus(input);

		c.addListener(listener);
	}

	private void refresh() {
		if (client != null) init(client, width, height);
	}

	private void select(String key) {
		ChatClient c = ChatClient.INSTANCE;
		c.openConvo = key;
		c.unread.remove(key);
		refresh();
	}

	private void logout() {
		ChatClient.INSTANCE.disconnect();
		Config.INSTANCE.password = "";
		Config.save();
		if (client != null) client.setScreen(parent);
	}

	private void submit() {
		ChatClient c = ChatClient.INSTANCE;
		String text = draft.trim();
		if (text.isEmpty()) return;
		input.setText("");
		if (text.startsWith("/")) {
			command(c, text);
			return;
		}
		String key = c.openConvo == null ? "home" : c.openConvo;
		if (key.startsWith("dm:")) c.sendDm(key.substring(3), text);
		else if (key.startsWith("grp:")) c.sendGroupMsg(key.substring(4), text);
		else c.notice("Open a friend or group first (type /help)");
	}

	private void command(ChatClient c, String text) {
		String[] p = text.substring(1).trim().split("\\s+");
		String a = p[0].toLowerCase();
		if (a.equals("help")) {
			select("home");
		} else if (a.equals("friend") && p.length >= 3) {
			switch (p[1].toLowerCase()) {
				case "add" -> c.friendAdd(p[2]);
				case "accept" -> c.friendAccept(p[2]);
				case "remove" -> c.friendRemove(p[2]);
				default -> c.notice("Unknown option. Type /help");
			}
		} else if (a.equals("group") && p.length >= 3) {
			switch (p[1].toLowerCase()) {
				case "create" -> c.groupCreate(p[2]);
				case "add" -> {
					ChatClient.Group g = p.length >= 4 ? c.findGroup(p[2]) : null;
					if (g == null) c.notice("Usage: /group add GROUP NAME (you must be in the group)");
					else c.groupAdd(g.id, p[3]);
				}
				case "leave" -> {
					ChatClient.Group g = c.findGroup(p[2]);
					if (g == null) c.notice("Unknown group");
					else c.groupLeave(g.id);
				}
				default -> c.notice("Unknown option. Type /help");
			}
		} else {
			c.notice("Unknown command. Type /help");
		}
	}

	private List<OrderedText> buildLines(int wrapWidth) {
		ChatClient c = ChatClient.INSTANCE;
		List<OrderedText> out = new ArrayList<>();
		String key = c.openConvo == null ? "home" : c.openConvo;

		if (c.status != ChatClient.Status.ONLINE) {
			out.addAll(textRenderer.wrapLines(Text.literal(c.statusText).formatted(Formatting.RED), wrapWidth));
		}

		if (key.equals("home")) {
			out.add(Text.literal("Friend Chat - connected as " + c.self).formatted(Formatting.GREEN).asOrderedText());
			out.add(Text.literal(" ").asOrderedText());
			String[] help = {
				"/friend add NAME", "/friend accept NAME", "/friend remove NAME",
				"/group create NAME", "/group add GROUP NAME", "/group leave GROUP"
			};
			for (String h : help) out.add(Text.literal(h).formatted(Formatting.AQUA).asOrderedText());
			if (!c.requests.isEmpty()) {
				out.add(Text.literal(" ").asOrderedText());
				out.add(Text.literal("Friend requests: " + String.join(", ", c.requests)).formatted(Formatting.GOLD).asOrderedText());
			}
			if (!c.notices.isEmpty()) {
				out.add(Text.literal(" ").asOrderedText());
				int from = Math.max(0, c.notices.size() - 8);
				for (int i = from; i < c.notices.size(); i++) {
					out.addAll(textRenderer.wrapLines(Text.literal("- " + c.notices.get(i)).formatted(Formatting.YELLOW), wrapWidth));
				}
			}
			return out;
		}

		if (key.startsWith("grp:")) {
			ChatClient.Group g = c.groups.get(key.substring(4));
			if (g != null) {
				out.addAll(textRenderer.wrapLines(
					Text.literal("# " + g.name + " - " + String.join(", ", g.members)).formatted(Formatting.AQUA), wrapWidth));
			}
		} else if (key.startsWith("dm:")) {
			out.add(Text.literal("Chat with " + key.substring(3)).formatted(Formatting.AQUA).asOrderedText());
		}

		List<ChatClient.Msg> msgs = c.history.get(key);
		if (msgs != null) {
			for (ChatClient.Msg m : msgs) {
				String time = TIME.format(LocalTime.ofInstant(Instant.ofEpochMilli(m.ts()), ZoneId.systemDefault()));
				MutableText line = Text.literal("[" + time + "] ").formatted(Formatting.GRAY);
				line.append(Text.literal(m.from() + ": ").formatted(m.from().equals(c.self) ? Formatting.AQUA : Formatting.YELLOW));
				line.append(Text.literal(m.text()).formatted(Formatting.WHITE));
				out.addAll(textRenderer.wrapLines(line, wrapWidth));
			}
		}
		return out;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		int x0 = LIST_W + 12;
		int x1 = width - 6;
		int y0 = 6;
		int y1 = height - 32;
		ctx.fill(x0, y0, x1, y1, 0xAA000000);

		List<OrderedText> lines = buildLines(x1 - x0 - 8);
		int lh = textRenderer.fontHeight + 2;
		int maxLines = Math.max(1, (y1 - y0 - 8) / lh);
		int start = Math.max(0, lines.size() - maxLines);
		int y = y0 + 4;
		for (int i = start; i < lines.size(); i++) {
			ctx.drawTextWithShadow(textRenderer, lines.get(i), x0 + 4, y, 0xFFFFFFFF);
			y += lh;
		}
	}

	@Override
	public void close() {
		if (client != null) client.setScreen(parent);
	}

	@Override
	public void removed() {
		ChatClient.INSTANCE.removeListener(listener);
		ChatClient.INSTANCE.openConvo = null;
	}
}
