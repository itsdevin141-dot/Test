package com.friendchat;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class LoginScreen extends Screen {
	private final Screen parent;
	private TextFieldWidget url, name, pass;
	private final Runnable listener = this::onChange;

	public LoginScreen(Screen parent) {
		super(Text.literal("Friend Chat"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = width / 2;
		int y = height / 2 - 50;

		url = new TextFieldWidget(textRenderer, cx - 100, y, 200, 20, Text.literal("Server"));
		url.setMaxLength(200);
		url.setText(Config.INSTANCE.url);
		name = new TextFieldWidget(textRenderer, cx - 100, y + 35, 200, 20, Text.literal("Name"));
		name.setMaxLength(16);
		name.setText(Config.INSTANCE.username);
		pass = new TextFieldWidget(textRenderer, cx - 100, y + 70, 200, 20, Text.literal("Password"));
		pass.setMaxLength(64);
		pass.setText(Config.INSTANCE.password);

		addDrawableChild(url);
		addDrawableChild(name);
		addDrawableChild(pass);
		addDrawableChild(ButtonWidget.builder(Text.literal("Connect"), b -> connect())
			.dimensions(cx - 100, y + 100, 98, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
			.dimensions(cx + 2, y + 100, 98, 20).build());
		setInitialFocus(name);

		ChatClient.INSTANCE.addListener(listener);
	}

	private void connect() {
		Config.INSTANCE.url = url.getText().trim();
		Config.INSTANCE.username = name.getText().trim();
		Config.INSTANCE.password = pass.getText();
		Config.save();
		ChatClient.INSTANCE.connect();
	}

	private void onChange() {
		if (ChatClient.INSTANCE.status == ChatClient.Status.ONLINE && client != null) {
			client.setScreen(new ChatScreen(parent));
		}
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		int cx = width / 2;
		int y = height / 2 - 50;
		ctx.drawTextWithShadow(textRenderer, "Friend Chat login", cx - 100, y - 30, 0xFFFFFFFF);
		ctx.drawTextWithShadow(textRenderer, "Server URL", cx - 100, y - 11, 0xFFA0A0A0);
		ctx.drawTextWithShadow(textRenderer, "Name", cx - 100, y + 24, 0xFFA0A0A0);
		ctx.drawTextWithShadow(textRenderer, "Password", cx - 100, y + 59, 0xFFA0A0A0);
		String st = ChatClient.INSTANCE.statusText;
		if (!st.isEmpty()) {
			int color = ChatClient.INSTANCE.status == ChatClient.Status.AUTH_FAILED ? 0xFFFF5555 : 0xFFFFFF55;
			ctx.drawTextWithShadow(textRenderer, st, cx - 100, y + 126, color);
		}
	}

	@Override
	public void close() {
		if (client != null) client.setScreen(parent);
	}

	@Override
	public void removed() {
		ChatClient.INSTANCE.removeListener(listener);
	}
}
