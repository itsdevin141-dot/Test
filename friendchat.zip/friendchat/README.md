# Friend Chat (Fabric 1.21.11)

## 1) Server (Node.js 18+, works on Termux)
    cd server
    npm install
    node server.js adduser Ahmed secret123      # add each friend yourself
    node server.js                              # listens on port 8080
Expose it with Cloudflare Tunnel (gives wss://...) or Playit.gg.

## 2) Mod
1. Download the Fabric template for 1.21.11 (Yarn) from https://fabricmc.net/develop/template/ and copy its
   `gradlew`, `gradlew.bat` and `gradle/` folder into `mod/`.
2. In `mod/` run: `./gradlew build`  (JDK 21 required).
3. Take `build/libs/friendchat-1.0.0.jar` and put it in `mods/` next to Fabric API 0.141.1+1.21.11.

## Use
Press the "Friends" button on the main menu or pause menu, enter server URL, name, password.
Commands: /friend add|accept|remove NAME, /group create NAME, /group add GROUP NAME, /group leave GROUP.
