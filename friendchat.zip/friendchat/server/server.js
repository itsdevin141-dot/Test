'use strict';
// Friend Chat server: accounts, friends, DMs, groups, online status.
// Usage:  node server.js adduser NAME PASSWORD | deluser NAME | listusers | (no args = run server)
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const DB_FILE = process.env.DB_FILE || 'data.json';
const PORT = parseInt(process.env.PORT || '8080', 10);
const NAME_RE = /^[A-Za-z0-9_]{3,16}$/;
const GROUP_RE = /^[A-Za-z0-9_-]{1,20}$/;
const MAX_TEXT = 500;
const MAX_HISTORY = 200;

let db = { users: {}, friends: {}, requests: {}, groups: {}, messages: {} };
if (fs.existsSync(DB_FILE)) db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));

let saveTimer = null;
function writeDb() {
  fs.writeFileSync(DB_FILE + '.tmp', JSON.stringify(db));
  fs.renameSync(DB_FILE + '.tmp', DB_FILE);
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; writeDb(); }, 500);
}

const lower = (s) => String(s || '').toLowerCase();
const nm = (u) => (db.users[u] ? db.users[u].name : u);
const dmKey = (a, b) => 'dm:' + [a, b].sort().join('|');
const isFriend = (a, b) => (db.friends[a] || []).includes(b);
const clean = (t) => String(t || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, MAX_TEXT);

// ---------- CLI ----------
const [, , cmd, argA, argB] = process.argv;
if (cmd === 'adduser') {
  if (!NAME_RE.test(argA || '') || !argB) { console.log('Usage: node server.js adduser NAME PASSWORD (name: 3-16 letters/digits/_)'); process.exit(1); }
  const u = lower(argA);
  db.users[u] = { name: argA, hash: bcrypt.hashSync(argB, 10) };
  db.friends[u] = db.friends[u] || [];
  db.requests[u] = db.requests[u] || [];
  writeDb(); console.log('User saved: ' + argA); process.exit(0);
}
if (cmd === 'deluser') {
  const u = lower(argA);
  if (!db.users[u]) { console.log('No such user'); process.exit(1); }
  delete db.users[u]; delete db.friends[u]; delete db.requests[u];
  for (const k of Object.keys(db.friends)) db.friends[k] = db.friends[k].filter((x) => x !== u);
  for (const k of Object.keys(db.requests)) db.requests[k] = db.requests[k].filter((x) => x !== u);
  for (const g of Object.values(db.groups)) g.members = g.members.filter((x) => x !== u);
  writeDb(); console.log('User deleted'); process.exit(0);
}
if (cmd === 'listusers') { console.log(Object.values(db.users).map((x) => x.name).join('\n')); process.exit(0); }

// ---------- Server ----------
const { WebSocketServer } = require('ws');
const wss = new WebSocketServer({ port: PORT, maxPayload: 8 * 1024 });
const online = new Map();   // lowercase name -> Set<ws>
const failures = new Map(); // ip -> { n, until }

function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }
function sendUser(u, obj) { const s = online.get(u); if (s) for (const ws of s) send(ws, obj); }
function info(u, text) { sendUser(u, { t: 'info', text }); }

function stateFor(u, withHistory) {
  const friends = (db.friends[u] || []).map((f) => ({ name: nm(f), online: online.has(f) }));
  const requests = (db.requests[u] || []).map(nm);
  const groups = Object.values(db.groups)
    .filter((g) => g.members.includes(u))
    .map((g) => ({ id: g.id, name: g.name, members: g.members.map(nm) }));
  const st = { t: 'state', friends, requests, groups };
  if (withHistory) {
    st.history = {};
    for (const f of db.friends[u] || []) st.history['dm:' + nm(f)] = (db.messages[dmKey(u, f)] || []).slice(-50);
    for (const g of groups) st.history['grp:' + g.id] = (db.messages['g:' + g.id] || []).slice(-50);
  }
  return st;
}
function pushState(u, withHistory) { sendUser(u, stateFor(u, withHistory)); }

function addMsg(key, from, text) {
  const m = { from: nm(from), text, ts: Date.now() };
  const arr = (db.messages[key] = db.messages[key] || []);
  arr.push(m);
  if (arr.length > MAX_HISTORY) arr.splice(0, arr.length - MAX_HISTORY);
  save();
  return m;
}

function broadcastPresence(u, isOn) {
  for (const f of db.friends[u] || []) sendUser(f, { t: 'presence', name: nm(u), online: isOn });
}

function makeFriends(a, b) {
  db.friends[a] = db.friends[a] || []; db.friends[b] = db.friends[b] || [];
  if (!db.friends[a].includes(b)) db.friends[a].push(b);
  if (!db.friends[b].includes(a)) db.friends[b].push(a);
  db.requests[a] = (db.requests[a] || []).filter((x) => x !== b);
  db.requests[b] = (db.requests[b] || []).filter((x) => x !== a);
  save();
  pushState(a, true); pushState(b, true);
  info(a, 'You are now friends with ' + nm(b)); info(b, 'You are now friends with ' + nm(a));
}

function handleLogin(ws, m, ip) {
  if (m.t !== 'login') return;
  const f = failures.get(ip);
  if (f && f.until > Date.now()) return send(ws, { t: 'auth_fail', reason: 'Too many attempts, wait a few minutes' });
  const u = lower(m.name);
  const rec = db.users[u];
  if (!rec || !bcrypt.compareSync(String(m.pass || ''), rec.hash)) {
    const r = failures.get(ip) || { n: 0, until: 0 };
    r.n++; if (r.n >= 5) { r.until = Date.now() + 5 * 60000; r.n = 0; }
    failures.set(ip, r);
    return send(ws, { t: 'auth_fail', reason: 'Wrong name or password' });
  }
  failures.delete(ip);
  ws.user = u;
  const set = online.get(u) || new Set();
  const first = set.size === 0;
  set.add(ws); online.set(u, set);
  send(ws, { t: 'auth_ok', name: rec.name });
  send(ws, stateFor(u, true));
  if (first) broadcastPresence(u, true);
}

function handle(u, ws, m) {
  switch (m.t) {
    case 'dm': {
      const to = lower(m.to); const text = clean(m.text);
      if (!text) return;
      if (!isFriend(u, to)) return info(u, 'You can only message friends');
      const msg = addMsg(dmKey(u, to), u, text);
      sendUser(to, { t: 'msg', convo: 'dm:' + nm(u), ...msg });
      sendUser(u, { t: 'msg', convo: 'dm:' + nm(to), ...msg });
      break;
    }
    case 'group_msg': {
      const g = db.groups[m.group]; const text = clean(m.text);
      if (!g || !g.members.includes(u) || !text) return;
      const msg = addMsg('g:' + g.id, u, text);
      for (const mem of g.members) sendUser(mem, { t: 'msg', convo: 'grp:' + g.id, ...msg });
      break;
    }
    case 'friend_add': {
      const t = lower(m.name);
      if (!db.users[t]) return info(u, 'No such user');
      if (t === u) return info(u, "That's you");
      if (isFriend(u, t)) return info(u, 'Already friends');
      if ((db.requests[u] || []).includes(t)) return makeFriends(u, t);
      const r = (db.requests[t] = db.requests[t] || []);
      if (!r.includes(u)) r.push(u);
      save();
      info(u, 'Friend request sent to ' + nm(t));
      info(t, nm(u) + ' sent you a friend request (/friend accept ' + nm(u) + ')');
      pushState(t, false);
      break;
    }
    case 'friend_accept': {
      const t = lower(m.name);
      if (!(db.requests[u] || []).includes(t)) return info(u, 'No request from that user');
      makeFriends(u, t);
      break;
    }
    case 'friend_remove': {
      const t = lower(m.name);
      if (!isFriend(u, t)) return info(u, 'Not your friend');
      db.friends[u] = db.friends[u].filter((x) => x !== t);
      db.friends[t] = (db.friends[t] || []).filter((x) => x !== u);
      save(); pushState(u, true); pushState(t, true);
      info(u, 'Removed ' + nm(t));
      break;
    }
    case 'group_create': {
      const name = String(m.name || '');
      if (!GROUP_RE.test(name)) return info(u, 'Group name: 1-20 letters, digits, _ or -');
      if (Object.values(db.groups).filter((g) => g.owner === u).length >= 20) return info(u, 'Too many groups');
      const id = crypto.randomBytes(4).toString('hex');
      db.groups[id] = { id, name, owner: u, members: [u] };
      save(); pushState(u, true);
      info(u, 'Group created: ' + name);
      break;
    }
    case 'group_add': {
      const g = db.groups[m.group]; const t = lower(m.name);
      if (!g || !g.members.includes(u)) return info(u, 'Unknown group');
      if (!isFriend(u, t)) return info(u, 'You can only add friends');
      if (g.members.includes(t)) return info(u, 'Already in the group');
      if (g.members.length >= 50) return info(u, 'Group is full');
      g.members.push(t); save();
      for (const mem of g.members) pushState(mem, mem === t);
      info(t, nm(u) + ' added you to group ' + g.name);
      break;
    }
    case 'group_leave': {
      const g = db.groups[m.group];
      if (!g || !g.members.includes(u)) return;
      g.members = g.members.filter((x) => x !== u);
      if (g.members.length === 0) { delete db.groups[g.id]; delete db.messages['g:' + g.id]; }
      save(); pushState(u, true);
      for (const mem of g.members) pushState(mem, false);
      info(u, 'Left group ' + g.name);
      break;
    }
  }
}

wss.on('connection', (ws, req) => {
  const ip = req.headers['cf-connecting-ip'] || req.socket.remoteAddress;
  ws.alive = true; ws.user = null;
  ws.on('pong', () => { ws.alive = true; });
  const authTimer = setTimeout(() => { if (!ws.user) ws.close(); }, 10000);
  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    try { if (!ws.user) handleLogin(ws, m, ip); else handle(ws.user, ws, m); } catch (e) { console.error(e); }
  });
  ws.on('close', () => {
    clearTimeout(authTimer);
    if (!ws.user) return;
    const set = online.get(ws.user);
    if (set) { set.delete(ws); if (set.size === 0) { online.delete(ws.user); broadcastPresence(ws.user, false); } }
  });
  ws.on('error', () => {});
});

setInterval(() => {
  for (const ws of wss.clients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; ws.ping(); }
}, 30000);

process.on('SIGINT', () => { if (saveTimer) writeDb(); process.exit(0); });
console.log('Friend Chat server listening on port ' + PORT);
